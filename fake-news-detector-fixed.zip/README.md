# Fake News Detector

A Python fake-news detector that blends **three independent signals** into one
explainable verdict, plus a small **web app** where you paste an article and see
the result.

```
┌─────────────────────────────────────────────────────────────────┐
│  Article text (+ optional headline / source URL)                │
└───────────────┬─────────────────────┬───────────────────┬───────┘
                │                     │                   │
        ┌───────▼───────┐    ┌────────▼────────┐  ┌───────▼────────┐
        │  1. ML model  │    │ 2. AI reasoning │  │ 3. Reputation  │
        │ word+char     │    │ LLM *or* offline│  │ domain table + │
        │ TF-IDF + style│    │ cue analyser    │  │ attribution    │
        └───────┬───────┘    └────────┬────────┘  └───────┬────────┘
                └─────────── weighted blend ─────────────┘
                                    │
                     ┌──────────────▼───────────────┐
                     │ Verdict + confidence + why   │
                     └──────────────────────────────┘
```

* **ML model** — a scikit-learn classifier (word + character TF-IDF plus
  stylometric features → calibrated logistic regression). Trains in seconds on a
  CPU, outputs `P(fake)`, and explains itself via its linear coefficients.
* **AI reasoning** — an LLM judgment when an OpenAI-compatible key is set,
  otherwise a transparent offline analyser that scores sensationalism, conspiracy
  framing, share-bait, urgency and attribution quality.
* **Source reputation** — a curated domain-reliability table (editable) plus
  attribution-hygiene checks (named sources, quotes, datelines).

Everything works **out of the box**: the repo ships a trained model and a
balanced sample dataset, and no signal requires network access.

---

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1) Web app  ->  open http://127.0.0.1:5000
python app.py

# 2) Command line
python -m fake_news_detector.cli "SHOCKING!! You won't believe what they're hiding..."
python -m fake_news_detector.cli --file article.txt --url https://reuters.com/world
cat article.txt | python -m fake_news_detector.cli --json
```

Example CLI output:

```
Verdict: Likely Fake   (fake-leaning 90%, confidence: high)
  [real                         fake]
  [###########################---]

Signals (weight):
  - ml          100.0%   (weight 55%)
  - reasoning   100.0%   (weight 25%)
  - reputation   50.0%   (weight 20%)

Warning signs:
  ! Sensational / clickbait framing - e.g. "you won't believe", "shocking"
  ! Conspiracy / cover-up language - e.g. "big pharma"
  ! Urgency / share-bait - e.g. "share this"
```

---

## How it works

### 1. The ML signal (`fake_news_detector/model.py`)
`TfidfVectorizer(word, 1–2 grams)` ⊕ `TfidfVectorizer(char_wb, 3–5 grams)` ⊕
`StylometricFeatures` → **calibrated Logistic Regression**. Word n-grams capture
*what* is said; character n-grams and style features (caps ratio, exclamation
density, vocabulary richness, stop-word ratio, URLs) capture *how* it is said —
useful when a topic is unseen. The linear model doubles as its own explanation:
`FakeNewsModel.explain()` returns the n-grams that pushed the document toward
fake or real.

### 2. The AI-reasoning signal (`fake_news_detector/reasoning.py`)
If `FND_LLM_API_KEY` (or `OPENAI_API_KEY`) is set, the text is sent to an
OpenAI-compatible `/chat/completions` endpoint and parsed into a structured
judgment. If not — or if the call fails — it falls back to `heuristic_reason()`,
a deterministic cue analyser. The fallback is the default; the LLM is a drop-in
upgrade.

### 3. The reputation signal (`fake_news_detector/reputation.py`)
Extracts domains mentioned in the text and looks them up in a curated table
(`data/sources.csv` overrides/extends the built-in list of ~40 outlets), then
adjusts the score for attribution hygiene: concrete attribution
("according to", "told Reuters", "peer-reviewed") lowers it; vague attribution
("reportedly", "sources say", "anonymous insider") raises it.

### Blending (`fake_news_detector/detector.py`)
Weighted mean with default weights `ml 0.55 / reasoning 0.25 / reputation 0.20`.
Weights are **renormalised** over whichever signals are actually available, so
the detector still works with no trained model. Thresholds: `≥ 0.62` →
*Likely Fake*, `≤ 0.38` → *Likely Real*, otherwise *Uncertain*.

---

## Training your own model

```bash
# Optional: download the full ~6,300-article public corpus and rebuild the sample
python scripts/fetch_dataset.py --rows 4000

# Train and save models/detector.joblib + models/metrics.json
python scripts/train.py --data data/sample_data.csv
```

Shipped model (trained on the bundled 2,000-article balanced sample):

| Metric | Value |
|---|---|
| Accuracy | ~0.91 |
| F1 (fake) | ~0.91 |
| ROC-AUC | ~0.97 |
| 5-fold CV F1 | ~0.91 ± 0.01 |

Provide your own CSV with `title, text, label` (`label` ∈ {real, fake} or 0/1)
and point `--data` at it.

### Enabling the LLM reasoning backend

```bash
export FND_LLM_API_KEY="sk-..."                       # required to switch it on
export FND_LLM_BASE_URL="https://api.openai.com/v1"   # any OpenAI-compatible endpoint
export FND_LLM_MODEL="gpt-4o-mini"                    # your model of choice
python app.py
```

---

## Project layout

```
fake-news-detector/
├── app.py                       # Flask web server
├── fake_news_detector/
│   ├── preprocess.py            # normalise / tokenise (no NLTK downloads)
│   ├── features.py              # stylometric transformer
│   ├── model.py                 # ML classifier + explanations
│   ├── reasoning.py             # LLM + offline cue analyser
│   ├── reputation.py            # domain table + attribution checks
│   ├── detector.py              # blends the three signals
│   └── cli.py                   # command-line entry point
├── scripts/
│   ├── fetch_dataset.py         # download the public dataset
│   ├── prepare_data.py          # build a balanced sample CSV
│   └── train.py                 # train + save model & metrics
├── templates/index.html         # web UI
├── static/{style.css,app.js}    # web UI assets
├── data/
│   ├── sample_data.csv          # bundled balanced sample (works offline)
│   └── sources.csv              # editable source-reputation table
├── models/detector.joblib       # pre-trained model
└── tests/test_detector.py       # pytest suite
```

---

## The bundled dataset

`data/sample_data.csv` is a balanced 2,000-article subset of the widely used
"fake or real news" corpus (a cleaned version of the Kaggle *Fake and real news
dataset*, itself derived from the ISOT dataset). It contains `id, title, text,
label`. The full corpus can be re-fetched with `scripts/fetch_dataset.py`.

> **Note on provenance:** that corpus is US-politics-heavy and its "fake" and
> "real" articles were scraped from different site families, so a classifier can
> partly key on source style rather than pure factuality. The bundled sample is
> truncated to 2,500 characters per article, which further blunts some of those
> cues, and the reputation/attribution layers are deliberately present to
> counterbalance this. Treat the ML score as **one** input, never the verdict.

---

## Limitations & responsible use

* **This is a screening aid, not an oracle.** A style-based model cannot confirm
  whether a specific claim is true. A confidently written falsehood can pass; a
  poorly written truth can be flagged.
* **Domain shift.** A model trained on US political news generalises imperfectly
  to other topics, languages and outlets. Retrain on in-domain data for serious
  use.
* **Topic bias.** Words like "Trump" or "Clinton" carry learned weight from the
  training era — never read the explanation chips as reasons on their own.
* **LLM backend caveat.** LLM judgments are plausible-sounding but unverified;
  they are weighted as a minority signal for that reason.
* **Always verify** important claims with primary sources and established
  fact-checkers (Reuters, AP, Snopes, PolitiFact, AFP Fact Check).

## Deploy

The project is deployment-ready out of the box: a WSGI entry point (`wsgi.py`),
`gunicorn` in the requirements, a `Procfile`, a `Dockerfile` and a `render.yaml`.

```bash
# Any host that runs a Python web app (Render, Railway, Fly.io, Heroku, a VPS…)
pip install -r requirements.txt
gunicorn wsgi:app --bind 0.0.0.0:$PORT --workers 2 --preload --timeout 120
```

**Docker**

```bash
docker build -t fake-news-detector .
docker run -p 8000:8000 -e PORT=8000 fake-news-detector
# open http://localhost:8000
```

Notes:

* `--preload` loads the 3 MB model **once** and shares it with every worker, so
  memory stays low; `app.py` also degrades gracefully (reasoning + reputation
  only) if the model cannot be unpickled on a different scikit-learn version.
* Most platforms inject `PORT` for you — the app reads it from the environment.
* Copy `.env.example` to `.env` (or use your host's dashboard) to switch on the
  LLM backend. Never commit `.env`.
* Health check endpoint: `GET /api/health`.
* The 30 MB raw corpus (`data/raw_*.csv`) is excluded from the archive and from
  the Docker image; the 4.4 MB sample and the trained model are included.

## License

Sample code released for educational use. The bundled dataset retains the terms
of its upstream source (Kaggle / ISOT).
