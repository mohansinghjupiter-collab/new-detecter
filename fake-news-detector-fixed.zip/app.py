#!/usr/bin/env python3
"""Flask web app for the fake-news detector.

    python app.py                 # then open http://127.0.0.1:5000
    FND_LLM_API_KEY=... python app.py   # enable the LLM reasoning backend

Endpoint summary
----------------
GET  /            the single-page UI
POST /api/detect  {"text": "...", "title": "...", "source_url": "..."} -> verdict JSON
GET  /api/health  liveness + which signals are active
"""

from __future__ import annotations

import json
import os

from flask import Flask, jsonify, render_template, request

from fake_news_detector import reasoning
from fake_news_detector.detector import Detector

HERE = os.path.dirname(os.path.abspath(__file__))
METRICS_PATH = os.path.join(HERE, "models", "metrics.json")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB of pasted text is plenty


def _load_detector() -> Detector:
    try:
        det = Detector.load_default()
    except Exception as exc:  # noqa: BLE001 - never let startup crash the UI
        app.logger.warning("Model unavailable (%s); running without the ML signal.", exc)
        det = Detector(model=None)
    return det


DETECTOR = _load_detector()


def _load_metrics() -> dict:
    if os.path.exists(METRICS_PATH):
        try:
            with open(METRICS_PATH, encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            pass
    return {}


@app.route("/")
def index():
    return render_template(
        "index.html",
        metrics=_load_metrics(),
        has_model=DETECTOR.has_model,
        llm_backend=reasoning.llm_available(),
    )


@app.route("/api/health")
def health():
    return jsonify(
        {
            "status": "ok",
            "ml_signal": DETECTOR.has_model,
            "reasoning_backend": "llm" if reasoning.llm_available() else "heuristic",
            "model_metrics": _load_metrics(),
        }
    )


@app.route("/api/detect", methods=["POST"])
def detect():
    payload = request.get_json(silent=True) or {}
    text = (payload.get("text") or "").strip()
    if len(text) < 20:
        return jsonify({"error": "Please paste at least a couple of sentences (20+ characters)."}), 400

    try:
        result = DETECTOR.detect(
            text=text,
            title=(payload.get("title") or "").strip(),
            source_url=(payload.get("source_url") or "").strip(),
        )
    except Exception as exc:  # noqa: BLE001
        app.logger.exception("detection failed")
        return jsonify({"error": f"Analysis failed: {exc}"}), 500

    return jsonify(result.as_dict())


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    print(f"Fake News Detector running on http://127.0.0.1:{port}")
    print(f"  ML signal: {'on' if DETECTOR.has_model else 'off (no trained model)'}")
    print(f"  Reasoning: {'LLM' if reasoning.llm_available() else 'offline heuristic'}")
    app.run(host="0.0.0.0", port=port, debug=debug)
