"""Command-line interface:  python -m fake_news_detector.cli "some article text" """

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional, Sequence

from .detector import Detector


def _read_input(args) -> str:
    if args.file:
        with open(args.file, encoding="utf-8") as fh:
            return fh.read()
    if args.text:
        return " ".join(args.text)
    if not sys.stdin.isatty():
        return sys.stdin.read()
    raise SystemExit("Provide article text as an argument, with --file, or on stdin.")


def _print_pretty(result) -> None:
    bar_len = 30
    filled = int(round(result.fake_probability * bar_len))
    bar = "#" * filled + "-" * (bar_len - filled)
    print(f"\nVerdict: {result.verdict}   (fake-leaning {result.fake_probability:.0%}, confidence: {result.confidence})")
    print(f"  [{'real' + ' ' * (bar_len - 9)}{'fake'}]")
    print(f"  [{bar}]")
    print("\nSignals (weight):")
    for name, val in result.signals.items():
        print(f"  - {name:<11} {val:>5.1%}   (weight {result.weights.get(name, 0)*100:.0f}%)")
    if result.red_flags:
        print("\nWarning signs:")
        for f in result.red_flags:
            print(f"  ! {f}")
    if result.green_flags:
        print("\nReassuring signs:")
        for f in result.green_flags:
            print(f"  + {f}")
    fk = result.explanation.get("fake_terms", [])
    rl = result.explanation.get("real_terms", [])
    if fk:
        print("\nWords pushing toward FAKE: " + ", ".join(d["term"] for d in fk))
    if rl:
        print("Words pushing toward REAL: " + ", ".join(d["term"] for d in rl))
    print(f"\nSummary: {result.summary}\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fake-news-detector",
        description="Analyse a news article for misinformation signals.",
    )
    parser.add_argument("text", nargs="*", help="Article text (quote it).")
    parser.add_argument("-f", "--file", help="Read article text from a file.")
    parser.add_argument("--title", default="", help="Optional headline.")
    parser.add_argument("--url", default="", help="Optional source URL.")
    parser.add_argument("--model", default=None, help="Path to a trained model artifact.")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")
    parser.add_argument(
        "--no-llm", action="store_true", help="Force the offline reasoning analyser."
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    text = _read_input(args)

    if args.model:
        from .model import FakeNewsModel

        detector = Detector(model=FakeNewsModel.load(args.model), prefer_llm=not args.no_llm)
    else:
        detector = Detector.load_default(prefer_llm=not args.no_llm)

    result = detector.detect(text, title=args.title, source_url=args.url)
    if args.json:
        print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))
    else:
        _print_pretty(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
