"""Custom scikit-learn transformer for stylometric / meta features.

Word and character TF-IDF capture *what* an article says. These numeric
features capture *how* it says it - shouting, punctuation, vocabulary richness,
attribution density - which are strong, largely topic-independent signals of
sensationalist or fabricated content.
"""

from __future__ import annotations

import math
import re

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

from .preprocess import STOPWORDS, normalize, tokenize

_WORD_RE = re.compile(r"[A-Za-z']+")
_ALLCAPS_RE = re.compile(r"\b[A-Z]{3,}\b")


class StylometricFeatures(BaseEstimator, TransformerMixin):
    """Turn raw documents into a small vector of style statistics."""

    # NB: deliberately length-NORMALISED. Raw article length differs between the
    # "fake" and "real" scraped corpora for reasons that have nothing to do with
    # truthfulness, so including it makes short pasted text look fabricated.
    FEATURE_NAMES = [
        "caps_ratio",
        "allcaps_word_ratio",
        "exclam_per_100w",
        "question_per_100w",
        "ellipsis_per_100w",
        "quote_per_100w",
        "digit_ratio",
        "avg_word_len",
        "type_token_ratio",
        "stopword_ratio",
        "url_count",
    ]

    def fit(self, X, y=None):  # noqa: D401 - sklearn API
        return self

    def transform(self, X):
        return np.asarray([self._one(t) for t in X], dtype=float)

    def get_feature_names_out(self, input_features=None):  # noqa: D401
        # The enclosing FeatureUnion already prefixes these with "style__".
        return np.asarray(self.FEATURE_NAMES, dtype=object)

    @staticmethod
    def _one(text: str) -> list[float]:
        raw = str(text or "")
        words = _WORD_RE.findall(raw)
        n_words = len(words) or 1
        letters = [c for c in raw if c.isalpha()]
        n_letters = len(letters) or 1

        norm_tokens = tokenize(normalize(raw))
        n_norm = len(norm_tokens) or 1

        per100 = 100.0 / n_words
        allcaps = len(_ALLCAPS_RE.findall(raw))

        return [
            sum(1 for c in letters if c.isupper()) / n_letters,
            allcaps / n_words,
            raw.count("!") * per100,
            raw.count("?") * per100,
            (raw.count("...") + raw.count("\u2026")) * per100,
            (raw.count('"') + raw.count("\u201c") + raw.count("\u201d")) * per100,
            sum(1 for c in raw if c.isdigit()) / max(len(raw), 1),
            (sum(len(w) for w in words) / n_words),
            len(set(w.lower() for w in words)) / n_words,
            sum(1 for t in norm_tokens if t in STOPWORDS) / n_norm,
            float(raw.lower().count("http://") + raw.lower().count("https://")),
        ]
