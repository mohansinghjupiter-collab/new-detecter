"""The machine-learning signal: a text classifier that returns P(fake)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import FeatureUnion, Pipeline

from .features import StylometricFeatures
from .preprocess import SKLEARN_STOPWORDS

DEFAULT_MODEL_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", "detector.joblib"
)

RANDOM_STATE = 42


@dataclass
class TrainMetrics:
    n_train: int
    n_test: int
    accuracy: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    cv_f1_mean: float
    cv_f1_std: float
    report: str = ""

    def as_dict(self) -> dict:
        return {
            "accuracy": round(self.accuracy, 4),
            "precision": round(self.precision, 4),
            "recall": round(self.recall, 4),
            "f1": round(self.f1, 4),
            "roc_auc": round(self.roc_auc, 4),
            "cv_f1_mean": round(self.cv_f1_mean, 4),
            "cv_f1_std": round(self.cv_f1_std, 4),
        }


@dataclass
class Explanation:
    fake_terms: list[tuple[str, float]] = field(default_factory=list)
    real_terms: list[tuple[str, float]] = field(default_factory=list)


class FakeNewsModel:
    """A bag-of-n-grams + stylometry classifier with an explainability helper.

    The estimator is a (calibrated) logistic regression, chosen because it is
    fast, needs no GPU, is robust on small data, and - crucially - exposes linear
    coefficients that make per-article explanations trivial.
    """

    def __init__(self, calibrate: bool = True, random_state: int = RANDOM_STATE):
        self.calibrate = calibrate
        self.random_state = random_state
        self.pipeline: Pipeline | None = None
        self.is_fitted: bool = False

    # ------------------------------------------------------------------ build
    def _make_features(self) -> FeatureUnion:
        word = TfidfVectorizer(
            analyzer="word",
            ngram_range=(1, 2),
            min_df=2,
            max_features=80_000,
            sublinear_tf=True,
            strip_accents="unicode",
            stop_words=list(SKLEARN_STOPWORDS),
        )
        char = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(3, 5),
            min_df=3,
            max_features=60_000,
            sublinear_tf=True,
        )
        return FeatureUnion(
            [("word", word), ("char", char), ("style", StylometricFeatures())]
        )

    def _make_estimator(self):
        base = LogisticRegression(
            C=4.0,
            max_iter=2000,
            class_weight="balanced",
            solver="liblinear",
            random_state=self.random_state,
        )
        if self.calibrate:
            # A tiny sigmoid calibration keeps the probabilities honest without
            # the cost of a full CV-based calibrator.
            return CalibratedClassifierCV(base, method="sigmoid", cv=3)
        return base

    def build(self) -> "FakeNewsModel":
        self.pipeline = Pipeline(
            [("features", self._make_features()), ("clf", self._make_estimator())]
        )
        return self

    # ------------------------------------------------------------------ train
    def train(
        self,
        texts: Sequence[str],
        labels: Sequence[int],
        test_size: float = 0.2,
        do_cv: bool = True,
    ) -> TrainMetrics:
        if self.pipeline is None:
            self.build()

        X = list(texts)
        y = np.asarray(labels, dtype=int)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=self.random_state, stratify=y
        )
        self.pipeline.fit(X_train, y_train)
        self.is_fitted = True

        probs = self._proba_fake(X_test)
        preds = (probs >= 0.5).astype(int)

        cv_mean = cv_std = float("nan")
        if do_cv:
            # Cross-validate a fresh clone on the *training* split only.
            from sklearn.base import clone

            cv_scores = cross_val_score(
                clone(self.pipeline), X, y, cv=5, scoring="f1", n_jobs=-1
            )
            cv_mean, cv_std = float(cv_scores.mean()), float(cv_scores.std())

        return TrainMetrics(
            n_train=len(X_train),
            n_test=len(X_test),
            accuracy=accuracy_score(y_test, preds),
            precision=precision_score(y_test, preds, zero_division=0),
            recall=recall_score(y_test, preds, zero_division=0),
            f1=f1_score(y_test, preds, zero_division=0),
            roc_auc=roc_auc_score(y_test, probs),
            cv_f1_mean=cv_mean,
            cv_f1_std=cv_std,
            report=classification_report(
                y_test, preds, target_names=["real", "fake"], zero_division=0
            ),
        )

    # ---------------------------------------------------------------- predict
    def _ensure_fitted(self):
        if not self.is_fitted or self.pipeline is None:
            raise RuntimeError(
                "Model is not fitted. Call train(...) or FakeNewsModel.load(...) first."
            )

    def _proba_fake(self, texts) -> np.ndarray:
        self._ensure_fitted()
        proba = self.pipeline.predict_proba(texts)
        classes = list(self.pipeline.named_steps["clf"].classes_)
        return proba[:, classes.index(1)]

    def predict_proba_fake(self, texts) -> np.ndarray:
        """Return P(fake) in [0, 1] for one text (str) or a list of texts."""
        single = isinstance(texts, str)
        arr = self._proba_fake([texts] if single else list(texts))
        return float(arr[0]) if single else arr

    # -------------------------------------------------------------- explanation
    def explain(self, text: str, top_k: int = 8, include: str = "word") -> Explanation:
        """Return the n-grams that pushed this document toward fake / real.

        Uses the surrogate logistic coefficients. When the calibrated wrapper is
        used we read the coefficients off the first calibrated fold's estimator,
        which is representative and avoids averaging fragility.

        ``include`` selects which feature families may appear in the result:
        ``"word"`` (default, most human-readable), ``"char"``, or ``"all"``.
        """
        self._ensure_fitted()
        clf = self.pipeline.named_steps["clf"]
        if hasattr(clf, "calibrated_classifiers_"):
            clf = clf.calibrated_classifiers_[0].estimator
        coef = clf.coef_[0]
        names = np.asarray(
            self.pipeline.named_steps["features"].get_feature_names_out(), dtype=object
        )

        vec = self.pipeline.named_steps["features"].transform([text])
        contributions = vec.toarray()[0] * coef

        if include == "all":
            mask = np.ones(len(names), dtype=bool)
        else:
            mask = np.array([str(n).startswith(f"{include}__") for n in names])
        idx = np.where(mask)[0]
        if idx.size == 0:
            return Explanation()
        sub = contributions[idx]

        fake_order = idx[np.argsort(sub)[::-1]][:top_k]
        real_order = idx[np.argsort(sub)][:top_k]

        def label(i: int) -> str:
            # Drop the "word__" / "char__" / "style__" family prefix for display.
            return str(names[i]).split("__", 1)[-1]

        fake_terms = [
            (label(i), float(contributions[i])) for i in fake_order if contributions[i] > 0
        ]
        real_terms = [
            (label(i), float(-contributions[i])) for i in real_order if contributions[i] < 0
        ]
        return Explanation(fake_terms=fake_terms, real_terms=real_terms)

    # --------------------------------------------------------------------- io
    def save(self, path: str = DEFAULT_MODEL_PATH) -> str:
        self._ensure_fitted()
        import joblib

        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        joblib.dump(self, path, compress=3)
        return path

    @classmethod
    def load(cls, path: str = DEFAULT_MODEL_PATH) -> "FakeNewsModel":
        import joblib

        if not os.path.exists(path):
            raise FileNotFoundError(
                f"No trained model at {path!r}. Run `python scripts/train.py` first."
            )
        model = joblib.load(path)
        if not isinstance(model, cls):
            raise TypeError(f"Unexpected artifact at {path!r}: {type(model)!r}")
        return model
