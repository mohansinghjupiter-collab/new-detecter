"""The AI-reasoning signal.

Two interchangeable backends sit behind one interface:

* :func:`llm_reason` - asks an OpenAI-compatible chat model to read the article
  and return a structured judgment. Enabled automatically when an API key is
  present in the environment; no third-party SDK is required (plain ``urllib``).
* :func:`heuristic_reason` - a transparent, offline cue-based analyser. This is
  the default so the detector always works out of the box.

Both return a :class:`ReasoningResult` carrying a fake-leaning score in [0, 1],
a short natural-language summary, and explicit red / green flags.
"""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field

# --------------------------------------------------------------------------- #
# Cue lexicons for the offline analyser
# --------------------------------------------------------------------------- #
_CUE_GROUPS: list[tuple[str, float, tuple[str, ...]]] = [
    (
        "Sensational / clickbait framing",
        0.9,
        (
            "you won't believe", "you wont believe", "shocking", "shocking truth",
            "mind blowing", "mind-blowing", "bombshell", "explosive", "outrageous",
            "jaw-dropping", "unbelievable", "insane", "epic", "breaks the internet",
            "goes viral", "must see", "must-see", "what happened next", "will blow your mind",
            "the truth about", "here's why", "this is huge", "wake up",
        ),
    ),
    (
        "Conspiracy / cover-up language",
        0.85,
        (
            "they don't want you to know", "they dont want you to know",
            "mainstream media", "msm", "cover-up", "coverup", "cover up",
            "secret agenda", "hidden agenda", "what they're hiding", "what theyre hiding",
            "the elite", "new world order", "plandemic", "false flag", "crisis actor",
            "sheeple", "do your own research", "wake up sheeple", "deep state",
            "big pharma", "the cabal", "exposed", "leaked documents reveal",
        ),
    ),
    (
        "Urgency / share-bait",
        0.7,
        (
            "share this", "share before", "before it's deleted", "before its deleted",
            "deleted soon", "spread the word", "must share", "share now",
            "act now", "time is running out", "they're deleting this",
            "theyre deleting this", "viral now", "forward this",
        ),
    ),
    (
        "Unverifiable authority",
        0.6,
        (
            "scientists confirm", "experts say", "doctors hate", "doctors are stunned",
            "scientists are baffled", "scientists baffled", "a friend of mine",
            "my cousin", "someone who works", "anonymous insider", "a source close to",
            "reports claim", "reportedly", "allegedly", "rumor has it",
        ),
    ),
    (
        "Absolute / emotive certainty",
        0.55,
        (
            "100% proof", "100 percent proof", "proven fact", "undeniable proof",
            "everyone knows", "no doubt", "the real truth", "totally fake",
            "completely destroyed", "obliterated", "slaughtered", "eviscerated",
            "humiliated", "destroyed in seconds", "you heard it here first",
        ),
    ),
    (
        "Health / miracle claims",
        0.75,
        (
            "miracle cure", "cures cancer", "cure for cancer", "big pharma hiding",
            "doctors won't tell you", "doctors wont tell you", "secret remedy",
            "one weird trick", "natural cure", "detox your", "big pharma doesn't want",
        ),
    ),
]

_CREDIBLE_MARKERS: list[tuple[str, float, str]] = [
    ("according to", 0.35, "Attributes claims to a named source"),
    ("spokesperson", 0.25, "Quotes an official spokesperson"),
    ("said in a statement", 0.3, "References an official statement"),
    ("court filing", 0.3, "Cites a primary legal document"),
    ("peer-reviewed", 0.3, "References peer-reviewed research"),
    ("study published in", 0.3, "Cites a published study"),
    ("percent", 0.15, "Includes numeric/statistical detail"),
    ("told reuters", 0.35, "Attributes to a wire service"),
    ("told the associated press", 0.35, "Attributes to a wire service"),
    ("declined to comment", 0.2, "Shows standard journalistic practice"),
]

_SOURCE_CONGESTION = re.compile(r"[!]{2,}|[?]{2,}|\?\?|!!")

_LLM_SYSTEM_PROMPT = (
    "You are a careful misinformation analyst. Judge the news text provided. "
    "Respond with ONLY a JSON object with keys: "
    '"fake_probability" (number 0-1), "summary" (one or two sentences), '
    '"red_flags" (array of short strings), "green_flags" (array of short strings). '
    "Be calibrated: a well-sourced, neutral report should score near 0; obvious "
    "fabrication, hoaxes or pure share-bait near 1. Do not use outside knowledge "
    "of specific events beyond general plausibility."
)


@dataclass
class ReasoningResult:
    score: float  # fake-leaning, 0..1
    summary: str
    red_flags: list[str] = field(default_factory=list)
    green_flags: list[str] = field(default_factory=list)
    backend: str = "heuristic"
    error: str | None = None

    def as_dict(self) -> dict:
        return {
            "score": round(self.score, 4),
            "summary": self.summary,
            "red_flags": self.red_flags,
            "green_flags": self.green_flags,
            "backend": self.backend,
            "error": self.error,
        }


# --------------------------------------------------------------------------- #
# Offline heuristic analyser
# --------------------------------------------------------------------------- #
def heuristic_reason(text: str) -> ReasoningResult:
    lowered = (text or "").lower()
    red_flags: list[str] = []
    green_flags: list[str] = []

    # Squash repeated hits: one category contributes once, scaled by hit count.
    raw = 0.0
    max_possible = sum(weight for _, weight, _ in _CUE_GROUPS)
    for label, weight, phrases in _CUE_GROUPS:
        hits = [p for p in phrases if p in lowered]
        if hits:
            intensity = min(1.0, 0.6 + 0.2 * (len(hits) - 1))
            raw += weight * intensity
            red_flags.append(
                f"{label} - e.g. " + ", ".join(f'"{h}"' for h in hits[:3])
            )

    # Punctuation shouting.
    excls = lowered.count("!")
    caps_words = len(re.findall(r"\b[A-Z]{3,}\b", text or ""))
    if _SOURCE_CONGESTION.search(text or ""):
        raw += 0.4
        red_flags.append("Multiple exclamation/question marks in a row (shouting).")
    if excls >= 4:
        raw += 0.25
        red_flags.append(f"High exclamation density ({excls} marks).")
    if caps_words >= 3:
        raw += 0.25
        red_flags.append(f"{caps_words} ALL-CAPS words used for emphasis.")

    fake_score = raw / (max_possible * 0.5) if max_possible else 0.0
    fake_score = max(0.0, min(1.0, fake_score))

    credible_bonus = 0.0
    for phrase, weight, note in _CREDIBLE_MARKERS:
        if phrase in lowered:
            credible_bonus += weight
            green_flags.append(note)
    credible_bonus = min(0.6, credible_bonus)
    fake_score = max(0.0, fake_score - credible_bonus)

    if not red_flags:
        green_flags.append("No sensationalist or conspiracy cue phrases detected.")

    if fake_score >= 0.6:
        summary = "The writing leans heavily on sensationalism, urgency or conspiracy framing."
    elif fake_score >= 0.3:
        summary = "Some stylistic warning signs are present, but nothing decisive."
    else:
        summary = "The language is comparatively measured and attributes claims to sources."

    return ReasoningResult(
        score=round(fake_score, 4),
        summary=summary,
        red_flags=red_flags,
        green_flags=green_flags,
        backend="heuristic",
    )


# --------------------------------------------------------------------------- #
# Optional LLM backend
# --------------------------------------------------------------------------- #
def llm_available() -> bool:
    return bool(_llm_config()[0])


def _llm_config() -> tuple[str | None, str, str]:
    key = (
        os.environ.get("FND_LLM_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("GENSKILL_API_KEY")
    )
    base = os.environ.get("FND_LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("FND_LLM_MODEL", "gpt-4o-mini")
    return key, base, model


def llm_reason(text: str, timeout: float = 30.0) -> ReasoningResult:
    """Query an OpenAI-compatible chat endpoint for a structured judgment."""
    key, base, model = _llm_config()
    if not key:
        raise RuntimeError(
            "No LLM API key configured (set FND_LLM_API_KEY or OPENAI_API_KEY)."
        )

    payload = {
        "model": model,
        "temperature": 0.0,
        "messages": [
            {"role": "system", "content": _LLM_SYSTEM_PROMPT},
            {"role": "user", "content": text[:6000]},
        ],
        "response_format": {"type": "json_object"},
    }
    req = urllib.request.Request(
        f"{base}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    content = data["choices"][0]["message"]["content"]
    parsed = json.loads(content)

    return ReasoningResult(
        score=float(max(0.0, min(1.0, parsed.get("fake_probability", 0.5)))),
        summary=str(parsed.get("summary", "")).strip(),
        red_flags=[str(x) for x in parsed.get("red_flags", [])],
        green_flags=[str(x) for x in parsed.get("green_flags", [])],
        backend=f"llm:{model}",
    )


def reason(text: str, prefer_llm: bool = True) -> ReasoningResult:
    """Run the LLM backend when configured, otherwise the offline analyser."""
    if prefer_llm and llm_available():
        try:
            return llm_reason(text)
        except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError, TimeoutError) as exc:
            fallback = heuristic_reason(text)
            fallback.error = f"LLM backend failed ({type(exc).__name__}); used offline analyser."
            return fallback
    return heuristic_reason(text)
