#!/usr/bin/env python3
"""Download the public labeled dataset used by this project.

The project ships a small balanced *sample* (``data/sample_data.csv``) so it
works offline out of the box. Run this script to fetch the full ~6,300-article
set and rebuild a larger sample if you want a stronger model.

Usage:
    python scripts/fetch_dataset.py                 # download to data/raw_fake_or_real_news.csv
    python scripts/fetch_dataset.py --rows 3000      # also rebuild a 3000-row sample
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT, "data")

# Mirrors of the widely-used "fake_or_real_news" corpus (a cleaned Kaggle
# fake/real news dataset). Listed in priority order with fallbacks.
MIRRORS = [
    "https://raw.githubusercontent.com/lutzhamel/fake-news/master/data/fake_or_real_news.csv",
    "https://raw.githubusercontent.com/susanli2016/NLP-with-Python/master/data/fake_or_real_news.csv",
]


def download(dest: str) -> str:
    last_err = None
    for url in MIRRORS:
        try:
            print(f"Downloading {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "fake-news-detector/1.0"})
            with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "wb") as out:
                out.write(resp.read())
            print(f"Saved {dest} ({os.path.getsize(dest) / 1e6:.1f} MB)")
            return dest
        except Exception as exc:  # noqa: BLE001 - report and try next mirror
            last_err = exc
            print(f"  failed: {exc}")
    raise SystemExit(f"All mirrors failed. Last error: {last_err}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Fetch the public labeled news dataset.")
    ap.add_argument("--out", default=os.path.join(DATA_DIR, "raw_fake_or_real_news.csv"))
    ap.add_argument("--rows", type=int, default=0, help="Also rebuild sample_data.csv with this many rows.")
    args = ap.parse_args()

    os.makedirs(DATA_DIR, exist_ok=True)
    download(args.out)

    if args.rows:
        from prepare_data import build_sample  # local import

        build_sample(args.out, os.path.join(DATA_DIR, "sample_data.csv"), per_class=args.rows // 2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
