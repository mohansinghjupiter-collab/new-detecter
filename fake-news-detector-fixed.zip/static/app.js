/* Fake News Detector — front-end logic */
(() => {
  const $ = (id) => document.getElementById(id);
  const textEl = $("text");
  const titleEl = $("title");
  const urlEl = $("source_url");
  const analyzeBtn = $("analyze");
  const results = $("results");
  const body = $("result-body");
  const placeholder = $("placeholder");
  const errBox = $("error");

  const SIGNAL_META = {
    ml: { name: "ML model", note: "Text-classifier probability" },
    reasoning: { name: "Language analysis", note: "Style & cue reasoning" },
    reputation: { name: "Source check", note: "Domain reputation & attribution" },
  };

  const EXAMPLES = [
    {
      title: "SHOCKING!! Doctors are HIDING this miracle cure",
      url: "",
      text:
        "SHOCKING!! You won't believe what doctors are hiding from you. " +
        "A miracle cure for cancer that big pharma doesn't want you to know about! " +
        "Doctors are STUNNED and the mainstream media refuses to report it. " +
        "Share this before they delete it!!! 100% PROOF that this works. " +
        "Wake up people — do your own research!",
    },
    {
      title: "Health ministry expands vaccination programme",
      url: "https://www.reuters.com/world",
      text:
        "According to a statement released on Tuesday, the Ministry of Health said the " +
        "vaccination programme would expand to two additional regions next month. " +
        "A spokesperson told Reuters that 1.2 million doses had been distributed so far, " +
        "citing data from the national health registry. Officials said the rollout would " +
        "be reviewed after 90 days and declined to comment on unpublished internal projections.",
    },
  ];
  let exampleIdx = 0;

  function updateCount() {
    $("count").textContent = textEl.value.length.toLocaleString();
  }

  function setLoading(on) {
    analyzeBtn.disabled = on;
    analyzeBtn.innerHTML = on ? '<span class="spinner"></span>Analyzing…' : "Analyze";
  }

  function pct(v) { return Math.round(v * 100) + "%"; }

  function signalColor(v) {
    // 0 (real) -> green, 0.5 -> amber, 1 (fake) -> red
    if (v >= 0.62) return "var(--red)";
    if (v <= 0.38) return "var(--green)";
    return "var(--amber)";
  }

  function verdictClass(verdict) {
    if (verdict === "Likely Fake") return "fake";
    if (verdict === "Likely Real") return "real";
    return "uncertain";
  }

  function render(data) {
    $("verdict").textContent = data.verdict;
    $("verdict").className = "verdict " + verdictClass(data.verdict);
    $("confidence").textContent = "confidence: " + data.confidence;

    const p = data.fake_probability;
    $("prob").textContent = pct(p);
    $("gauge-fill").style.width = pct(p);
    $("gauge-marker").style.left = `calc(${pct(p)} - 2px)`;
    $("gauge-fill").parentElement.style.filter = "none";

    // Signals
    const wrap = $("signals");
    wrap.innerHTML = "";
    Object.keys(data.signals).forEach((key) => {
      const v = data.signals[key];
      const meta = SIGNAL_META[key] || { name: key, note: "" };
      const w = data.weights[key] != null ? Math.round(data.weights[key] * 100) : null;
      const el = document.createElement("div");
      el.className = "signal";
      el.innerHTML =
        `<div class="s-name">${meta.name}</div>` +
        `<div class="s-val" style="color:${signalColor(v)}">${pct(v)}</div>` +
        `<div class="s-bar"><span style="width:${pct(v)};background:${signalColor(v)}"></span></div>` +
        `<div class="s-note">${meta.note}${w != null ? ` · weight ${w}%` : ""}</div>`;
      wrap.appendChild(el);
    });

    $("summary").textContent = data.summary || "";

    const red = $("red-flags"); red.innerHTML = "";
    (data.red_flags || []).forEach((f) => { const li = document.createElement("li"); li.textContent = f; red.appendChild(li); });
    if (!data.red_flags || !data.red_flags.length) { const li = document.createElement("li"); li.textContent = "None detected."; li.style.opacity = 0.6; red.appendChild(li); }

    const green = $("green-flags"); green.innerHTML = "";
    (data.green_flags || []).forEach((f) => { const li = document.createElement("li"); li.textContent = f; green.appendChild(li); });
    if (!data.green_flags || !data.green_flags.length) { const li = document.createElement("li"); li.textContent = "None detected."; li.style.opacity = 0.6; green.appendChild(li); }

    // Explanation terms
    const terms = $("terms"); terms.innerHTML = "";
    const fake = (data.explanation || {}).fake_terms || [];
    const real = (data.explanation || {}).real_terms || [];
    if (fake.length || real.length) {
      if (fake.length) {
        const g = document.createElement("div"); g.className = "term-group";
        g.innerHTML = `<span class="tg-label">Toward fake</span>` +
          fake.map((d) => `<span class="tchip fake">${escapeHtml(d.term)}</span>`).join("");
        terms.appendChild(g);
      }
      if (real.length) {
        const g = document.createElement("div"); g.className = "term-group";
        g.innerHTML = `<span class="tg-label">Toward real</span>` +
          real.map((d) => `<span class="tchip real">${escapeHtml(d.term)}</span>`).join("");
        terms.appendChild(g);
      }
    }

    placeholder.hidden = true;
    body.hidden = false;
    results.classList.remove("empty");
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function showError(msg) {
    errBox.textContent = msg;
    errBox.hidden = false;
    placeholder.hidden = true;
    body.hidden = true;
    results.classList.remove("empty");
  }

  async function analyze() {
    errBox.hidden = true;
    const text = textEl.value.trim();
    if (text.length < 20) { showError("Please paste at least a couple of sentences."); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/detect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, title: titleEl.value, source_url: urlEl.value }),
      });
      const data = await res.json();
      if (!res.ok) { showError(data.error || "Something went wrong."); return; }
      render(data);
    } catch (e) {
      showError("Network error: " + e.message);
    } finally {
      setLoading(false);
    }
  }

  analyzeBtn.addEventListener("click", analyze);
  textEl.addEventListener("input", updateCount);
  textEl.addEventListener("keydown", (e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") analyze(); });

  $("example").addEventListener("click", () => {
    const ex = EXAMPLES[exampleIdx % EXAMPLES.length];
    exampleIdx++;
    titleEl.value = ex.title;
    urlEl.value = ex.url;
    textEl.value = ex.text;
    updateCount();
  });

  $("clear").addEventListener("click", () => {
    titleEl.value = ""; urlEl.value = ""; textEl.value = "";
    updateCount();
    errBox.hidden = true;
    body.hidden = true; placeholder.hidden = false; results.classList.add("empty");
  });

  updateCount();
})();
