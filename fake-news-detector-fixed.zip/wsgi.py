"""WSGI entry point for production servers (gunicorn / uWSGI).

    gunicorn wsgi:app --bind 0.0.0.0:$PORT

The Flask application and the trained model are loaded once at import time, so
run gunicorn with ``--preload`` to share that work across worker processes.
"""

from app import app

# Expose the Flask app for `gunicorn wsgi:app`.
application = app

if __name__ == "__main__":
    import os

    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
